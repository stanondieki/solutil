# Azure Deployment

Backend deployed to Azure App Service.

Deployment triggered: 2025-09-29

Environment: Production
App Service: solutilconnect-backend-api